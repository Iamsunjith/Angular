export class Ingredient {
  constructor(public name: string, public amount: number) {}
}
// This is another wat an Model can be created, Check out the recipe Model to find the differences
