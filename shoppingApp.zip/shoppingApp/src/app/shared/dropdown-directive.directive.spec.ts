import { DropdownDirectiveDirective } from './dropdown-directive.directive';

describe('DropdownDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DropdownDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
